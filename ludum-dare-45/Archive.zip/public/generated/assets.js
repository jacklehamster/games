const files = {
    "alien": {
        "path": "assets/alien.png",
        "extension": "png",
        "filename": "alien.png",
        "filesize": 16806,
        "width": 384,
        "height": 384
    }
};