#!/bin/bash
cd "$(dirname "$0")" 
# ls -lh ASSETS > assets.txt
# ls -lh SOUNDS > sounds.txt
# python -m SimpleHTTPServer 8000


php -S localhost:8000